import random

class uicompute:
  def _select(member,counter):
    datalist=[]
    for i in range(counter):
      datalist.append(random.choice(member))
    return datalist

  def select_and_crossover(subjects,sem,sec,course):
    print(subjects)
    datalist=[]
    if sem==5 and len(subjects)<9:
      subjects.append("Leisure")
    num=random.randrange(1,10)
    if sem==5:       
      if num%2==0:
        datalist.append(subjects[0])
        datalist.append(subjects[1])
        datalist.append(subjects[2])
        datalist.append(subjects[3])
        datalist.append(subjects[6])

        
        datalist.append(subjects[4])
        datalist.append(subjects[5])
        datalist.append(subjects[8])
        datalist.append(subjects[1])
        datalist.append(subjects[7])

        
        datalist.append(subjects[1])
        datalist.append(subjects[2])
        datalist.append(subjects[3])
        datalist.append(subjects[4])
        datalist.append(subjects[5])
        datalist.append(subjects[8])
        datalist.append(subjects[0])

        
        datalist.append(subjects[2])
        datalist.append(subjects[4])
        datalist.append(subjects[8])
        datalist.append(subjects[3])
        datalist.append(subjects[6])

        
        datalist.append(subjects[5])
        datalist.append(subjects[2])
        datalist.append(subjects[4])
        datalist.append(subjects[0])
        datalist.append(subjects[7])

        
        datalist.append(subjects[3])
        datalist.append(subjects[5])
        datalist.append(subjects[1])
        datalist.append(subjects[8])
        datalist.append(subjects[0])
      else:   
        datalist.append(subjects[4])
        datalist.append(subjects[8])
        datalist.append(subjects[3])
        datalist.append(subjects[2])
        datalist.append(subjects[6])
        
        
        datalist.append(subjects[5])
        datalist.append(subjects[4])
        datalist.append(subjects[8])
        datalist.append(subjects[1])
        datalist.append(subjects[7])

        
        datalist.append(subjects[3])
        datalist.append(subjects[2])
        datalist.append(subjects[1])
        datalist.append(subjects[4])
        datalist.append(subjects[5])
        datalist.append(subjects[8])
        datalist.append(subjects[0])

        
        datalist.append(subjects[2])
        datalist.append(subjects[5])
        datalist.append(subjects[4])
        datalist.append(subjects[0])
        datalist.append(subjects[7])
        
        datalist.append(subjects[0])
        datalist.append(subjects[1])
        datalist.append(subjects[2])
        datalist.append(subjects[3])
        datalist.append(subjects[6])
        
        datalist.append(subjects[0])
        datalist.append(subjects[3])
        datalist.append(subjects[1])
        datalist.append(subjects[5])
        datalist.append(subjects[8])
    
    if sem==1 and sec=="A" and course=="BCA":
      
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append(subjects[9])
      datalist.append(subjects[9])

      datalist.append(subjects[4])
      datalist.append(subjects[5])
      datalist.append(subjects[6])
      datalist.append(subjects[7])
      datalist.append('leisure')
      datalist.append(subjects[8])

      datalist.append(subjects[0])
      datalist.append(subjects[10])
      datalist.append(subjects[10])
      datalist.append(subjects[1])
      datalist.append(subjects[2])
      datalist.append('leisure')
      
      datalist.append(subjects[3])
      datalist.append(subjects[4])
      datalist.append(subjects[5])
      datalist.append(subjects[6])
      datalist.append(subjects[7])
      datalist.append(subjects[8])
      
      datalist.append(subjects[0])
      datalist.append(subjects[6])
      datalist.append(subjects[7])
      datalist.append(subjects[1])	  
      datalist.append('leisure')
      datalist.append(subjects[2]) 

      
      
      datalist.append(subjects[8])
      datalist.append(subjects[4])      
      datalist.append(subjects[5])     
      datalist.append(subjects[3])

    if sem==1 and sec=="B" and course=="BCA":
      
      

      datalist.append(subjects[4])
      datalist.append(subjects[5])
      datalist.append(subjects[6])
      datalist.append(subjects[7])
      datalist.append('leisure')
      datalist.append(subjects[8])

      datalist.append(subjects[9])
      datalist.append(subjects[9])
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[2])
      datalist.append(subjects[3])

      datalist.append(subjects[3])
      datalist.append(subjects[4])
      datalist.append(subjects[5])
      datalist.append(subjects[6])
      datalist.append(subjects[7])
      datalist.append(subjects[8])
      
      datalist.append(subjects[0])
      datalist.append(subjects[6])
      datalist.append(subjects[7])
      datalist.append(subjects[1])	  
      datalist.append('leisure')
      datalist.append(subjects[2])
      
     
      datalist.append(subjects[1])
      datalist.append(subjects[10])
      datalist.append(subjects[10])
      datalist.append(subjects[2])
      datalist.append(subjects[0])
      datalist.append('leisure')
      
       

      
      
      datalist.append(subjects[3])
      datalist.append(subjects[5])      
      datalist.append(subjects[4])     
      datalist.append(subjects[8])


    if sem==2 and sec=="A" and course=="BCA":
      
      datalist.append(subjects[0])      
      datalist.append('liesure')
      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append(subjects[8])
      datalist.append(subjects[8])

      
      datalist.append('liesure')
      datalist.append(subjects[6])
      datalist.append(subjects[7])
      datalist.append(subjects[7])
      datalist.append(subjects[5])
      datalist.append('liesure')

      datalist.append(subjects[2])
      datalist.append(subjects[1])
      datalist.append('liesure')
      datalist.append(subjects[0])
      datalist.append(subjects[3])
      datalist.append(subjects[4])

      
      datalist.append('liesure')
      datalist.append(subjects[1])
      datalist.append('leisure')
      datalist.append(subjects[2])      
      datalist.append('liesure')
      datalist.append(subjects[3])
      
      datalist.append(subjects[4])
      datalist.append(subjects[5])      
      datalist.append('liesure')
      datalist.append(subjects[6])
      datalist.append(subjects[1])      
      datalist.append('liesure')

      datalist.append('liesure')
      datalist.append(subjects[4])
      datalist.append(subjects[0])
      datalist.append(subjects[5])
      
    if sem==2 and sec=="B" and course=="BCA":

      datalist.append(subjects[2])
      datalist.append(subjects[1])
      datalist.append('liesure')
      datalist.append(subjects[0])
      datalist.append(subjects[3])
      datalist.append(subjects[4])
      
      datalist.append(subjects[0])      
      datalist.append('liesure')
      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append(subjects[8])
      datalist.append(subjects[8])

      
      datalist.append('liesure')
      datalist.append(subjects[6])
      datalist.append(subjects[7])
      datalist.append(subjects[7])
      datalist.append(subjects[5])
      datalist.append('liesure')

      
      datalist.append(subjects[4])
      datalist.append(subjects[5])      
      datalist.append('liesure')
      datalist.append(subjects[6])
      datalist.append(subjects[1])      
      datalist.append('liesure')
      
      datalist.append('liesure')
      datalist.append(subjects[4])
      datalist.append('leisure')
      datalist.append(subjects[0])      
      datalist.append('liesure')
      datalist.append(subjects[5])
      
      

      datalist.append('liesure')
      datalist.append(subjects[1])
      datalist.append(subjects[2])
      datalist.append(subjects[3])
      
    if sem==3 and sec=="A" and course=="BCA":

      datalist.append('liesure')
      datalist.append('liesure')
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append('liesure')
      datalist.append('liesure')
      
      datalist.append(subjects[1])
      datalist.append(subjects[0])
      datalist.append('liesure')
      datalist.append('liesure')
      datalist.append('liesure')
      datalist.append('liesure')

      

      datalist.append('liesure')
      datalist.append(subjects[1])
      datalist.append(subjects[0])
      datalist.append('liesure')
      datalist.append('liesure')
      datalist.append('liesure')

      
      datalist.append(subjects[1])
      datalist.append(subjects[0])
      datalist.append('liesure')
      datalist.append('liesure')
      datalist.append('liesure')
      datalist.append('liesure')
      
      datalist.append('liesure')
      datalist.append('leisure')
      datalist.append('leisure')
      datalist.append('leisure')      
      datalist.append(subjects[2])
      datalist.append(subjects[2])
      
      

      datalist.append('Project')
      datalist.append('Project')
      datalist.append('Project')
      datalist.append('Project')
      

    if sem==3 and sec=="B" and course=="BCA":


      
      datalist.append(subjects[1])
      datalist.append(subjects[0])
      datalist.append('liesure')
      datalist.append('liesure')
      datalist.append('liesure')
      datalist.append('liesure')

      datalist.append('liesure')
      datalist.append('liesure')
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append('liesure')
      datalist.append('liesure')
      



      
      datalist.append(subjects[1])
      datalist.append(subjects[0])
      datalist.append('liesure')
      datalist.append('liesure')
      datalist.append('liesure')
      datalist.append('liesure')
      
      datalist.append('liesure')
      datalist.append(subjects[2])
      datalist.append(subjects[2])
      datalist.append('liesure')
      datalist.append('liesure')
      datalist.append('liesure')
      
      datalist.append('liesure')
      datalist.append('leisure')
      datalist.append('leisure')
      datalist.append('leisure')      
      datalist.append(subjects[1])
      datalist.append(subjects[0])
      
      

      datalist.append('Project')
      datalist.append('Project')
      datalist.append('Project')
      datalist.append('Project')

    if sem==1 and sec=="A" and course=="BCom":


      
      datalist.append(subjects[0])
      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append(subjects[1])
      datalist.append(subjects[4])
      datalist.append(subjects[5])

      datalist.append(subjects[6])
      datalist.append(subjects[7])
      datalist.append(subjects[1])
      datalist.append(subjects[8])
      datalist.append(subjects[0])
      datalist.append(subjects[2])
      



      
      datalist.append(subjects[6])
      datalist.append(subjects[4])
      datalist.append(subjects[5])
      datalist.append(subjects[8])
      datalist.append(subjects[7])
      datalist.append(subjects[0])
      
      datalist.append(subjects[3])
      datalist.append(subjects[2])
      datalist.append(subjects[1])
      datalist.append(subjects[4])
      datalist.append(subjects[6])
      datalist.append(subjects[5])
      
      datalist.append(subjects[0])
      datalist.append(subjects[7])
      datalist.append(subjects[1])
      datalist.append(subjects[3])
      datalist.append(subjects[4])
      datalist.append(subjects[2])
      
      

      datalist.append(subjects[6])
      datalist.append(subjects[5])
      datalist.append(subjects[7])
      datalist.append(subjects[8])

    if sem==2 and sec=="A" and course=="BCom":


      
      datalist.append(subjects[0])
      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append(subjects[1])
      datalist.append(subjects[4])
      datalist.append(subjects[5])

      datalist.append(subjects[6])
      datalist.append(subjects[7])
      datalist.append(subjects[1])
      datalist.append('liesure')
      datalist.append(subjects[0])
      datalist.append(subjects[2])
      



      
      datalist.append(subjects[6])
      datalist.append(subjects[4])
      datalist.append(subjects[5])
      datalist.append(subjects[3])
      datalist.append(subjects[7])
      datalist.append(subjects[0])
      
      datalist.append(subjects[3])
      datalist.append(subjects[2])
      datalist.append(subjects[1])
      datalist.append(subjects[4])
      datalist.append(subjects[6])
      datalist.append(subjects[5])
      
      datalist.append(subjects[7])
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[3])
      datalist.append(subjects[4])
      datalist.append(subjects[2])
      
      

      datalist.append(subjects[6])
      datalist.append(subjects[5])
      datalist.append(subjects[7])
      datalist.append('liesure')

    if sem==3 and sec=="A" and course=="BCom":


      
      datalist.append(subjects[0])
      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append(subjects[1])
      datalist.append(subjects[4])
      datalist.append(subjects[5])

      datalist.append(subjects[5])
      datalist.append(subjects[4])
      datalist.append(subjects[3])
      datalist.append(subjects[1])
      datalist.append(subjects[0])
      datalist.append(subjects[2])
      
      datalist.append(subjects[2])
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[3])
      datalist.append(subjects[5])
      datalist.append(subjects[4])
      
      datalist.append(subjects[4])
      datalist.append(subjects[1])
      datalist.append(subjects[3])
      datalist.append(subjects[2])
      datalist.append(subjects[5])
      datalist.append(subjects[0])
      
      datalist.append(subjects[1])
      datalist.append(subjects[3])
      datalist.append(subjects[5])
      datalist.append(subjects[4])
      datalist.append(subjects[2])
      datalist.append(subjects[0])
      
      

      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append(subjects[1])
      datalist.append(subjects[0])
    if sem==1 and sec=="A" and course=="BSc":


      
      datalist.append(subjects[0])
      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append(subjects[1])
      datalist.append(subjects[4])
      datalist.append(subjects[5])

      datalist.append(subjects[6])
      datalist.append(subjects[7])
      datalist.append(subjects[8])
      datalist.append(subjects[8])
      datalist.append(subjects[1])
      datalist.append('liesure')
      
      datalist.append(subjects[10])
      datalist.append(subjects[10])
      datalist.append(subjects[5])
      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append(subjects[4])

      
      
      datalist.append(subjects[6])
      datalist.append(subjects[7])
      datalist.append(subjects[8])
      datalist.append('liesure')
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      
      datalist.append(subjects[9])
      datalist.append(subjects[9])
      datalist.append(subjects[0])
      datalist.append(subjects[3])
      datalist.append(subjects[2])
      datalist.append(subjects[5])
      
      

      datalist.append(subjects[4])
      datalist.append(subjects[6])
      datalist.append(subjects[7])
      datalist.append(subjects[8])

    if sem==2 and sec=="A" and course=="BSc":


      
      datalist.append(subjects[0])
      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append(subjects[1])
      datalist.append(subjects[4])
      datalist.append(subjects[5])

      datalist.append(subjects[6])
      datalist.append(subjects[7])
      datalist.append(subjects[8])
      datalist.append(subjects[8])
      datalist.append(subjects[1])
      datalist.append('liesure')
      
      datalist.append(subjects[9])
      datalist.append(subjects[9])
      datalist.append(subjects[0])
      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append(subjects[4])
      
      datalist.append(subjects[6])
      datalist.append(subjects[7])
      datalist.append(subjects[3])
      datalist.append(subjects[1])
      datalist.append('liesure')
      datalist.append('liesure')
      
      datalist.append(subjects[5])
      datalist.append(subjects[1])
      datalist.append(subjects[0])
      datalist.append(subjects[3])
      datalist.append(subjects[2])
      datalist.append(subjects[5])
      
      

      datalist.append(subjects[4])
      datalist.append(subjects[6])
      datalist.append(subjects[7])
      datalist.append('liesure')

    if sem==3 and sec=="A" and course=="BSc":


      
      datalist.append(subjects[0])
      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append(subjects[1])
      datalist.append(subjects[4])
      datalist.append(subjects[4])

      datalist.append(subjects[5])
      datalist.append(subjects[5])
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[2])
      datalist.append('liesure')
      
      datalist.append(subjects[3])
      datalist.append('liesure')
      datalist.append('liesure')
      datalist.append('liesure')
      datalist.append(subjects[4])
      datalist.append(subjects[4])
      
      datalist.append(subjects[5])
      datalist.append(subjects[5])
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append('liesure')
      datalist.append('liesure')
      
      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append('liesure')
      datalist.append('liesure')
      
      

      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append('liesure')
      datalist.append('liesure')
    ''' 
    if sem==2 and sec=="C":

      datalist.append(subjects[4])
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[2])
      datalist.append(subjects[6])
      
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[4])
      datalist.append(subjects[3])
      datalist.append(subjects[5])

      datalist.append(subjects[3])
      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append(subjects[4])
      datalist.append(subjects[7])
      datalist.append(subjects[7])
      datalist.append('leisure')
      

      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[6])

      datalist.append(subjects[1])
      datalist.append(subjects[4])
      datalist.append(subjects[2])
      datalist.append(subjects[0])
      datalist.append(subjects[5])
      
      

    if sem==3 and sec=="A":

      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append(subjects[6])

      datalist.append(subjects[4])
      datalist.append(subjects[5])
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[7])

      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append(subjects[4])
      datalist.append(subjects[5])
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[8])
      
      datalist.append(subjects[3])
      datalist.append(subjects[4])
      datalist.append(subjects[5])
      datalist.append(subjects[0])
      datalist.append(subjects[6])

      datalist.append(subjects[1])
      datalist.append(subjects[2])
      datalist.append(subjects[8])
      datalist.append(subjects[9])
      datalist.append(subjects[7])

    if sem==3 and sec=="B":
      datalist.append(subjects[4])
      datalist.append(subjects[5])
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[7])

      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append(subjects[6])


      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append(subjects[4])
      datalist.append(subjects[5])
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[8])
      
      datalist.append(subjects[1])
      datalist.append(subjects[2])
      datalist.append(subjects[8])
      datalist.append(subjects[9])
      datalist.append(subjects[7])
      
      datalist.append(subjects[3])
      datalist.append(subjects[4])
      datalist.append(subjects[5])
      datalist.append(subjects[0])
      datalist.append(subjects[6])


    if sem==3 and sec=="C":

      datalist.append(subjects[1])
      datalist.append(subjects[2])
      datalist.append(subjects[8])
      datalist.append(subjects[9])
      datalist.append(subjects[7])
      
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append(subjects[6])

      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append(subjects[4])
      datalist.append(subjects[5])
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[8])
      
      datalist.append(subjects[3])
      datalist.append(subjects[4])
      datalist.append(subjects[5])
      datalist.append(subjects[0])
      datalist.append(subjects[6])

      datalist.append(subjects[4])
      datalist.append(subjects[5])
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[7])
      


    if sem==4 and sec=="A":
      datalist.append(subjects[4])
      datalist.append(subjects[5])
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[7])

      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append(subjects[6])


      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append(subjects[4])
      datalist.append(subjects[5])
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[8])
      
      datalist.append(subjects[1])
      datalist.append(subjects[2])
      datalist.append(subjects[8])
      datalist.append(subjects[9])
      datalist.append(subjects[7])
      
      datalist.append(subjects[3])
      datalist.append(subjects[4])
      datalist.append(subjects[5])
      datalist.append(subjects[0])
      datalist.append(subjects[6])

      


    if sem==4 and sec=="B":

      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append(subjects[6])

      datalist.append(subjects[4])
      datalist.append(subjects[5])
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[7])

      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append(subjects[4])
      datalist.append(subjects[5])
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[8])
      
      datalist.append(subjects[3])
      datalist.append(subjects[4])
      datalist.append(subjects[5])
      datalist.append(subjects[0])
      datalist.append(subjects[6])

      datalist.append(subjects[1])
      datalist.append(subjects[2])
      datalist.append(subjects[8])
      datalist.append(subjects[9])
      datalist.append(subjects[7])
      


    if sem==4 and sec=="C":

      datalist.append(subjects[3])
      datalist.append(subjects[4])
      datalist.append(subjects[5])
      datalist.append(subjects[0])
      datalist.append(subjects[6])
      
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append(subjects[6])

      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append(subjects[4])
      datalist.append(subjects[5])
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[8])
      

      datalist.append(subjects[1])
      datalist.append(subjects[2])
      datalist.append(subjects[8])
      datalist.append(subjects[9])
      datalist.append(subjects[7])

      datalist.append(subjects[4])
      datalist.append(subjects[5])
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[7])
      
      

      

      
      
    if sem==6 and sec=="A":
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append(subjects[6])

      
      datalist.append(subjects[4])
      datalist.append(subjects[5])
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[7])

      datalist.append(subjects[1])
      datalist.append(subjects[3])
      datalist.append(subjects[4])
      datalist.append(subjects[2])
      datalist.append(subjects[5])
      datalist.append(subjects[0])
      datalist.append('leisure')
      
      datalist.append(subjects[2])
      datalist.append(subjects[4])
      datalist.append(subjects[3])
      datalist.append(subjects[5])
      datalist.append(subjects[7])

      datalist.append(subjects[5])
      datalist.append(subjects[2])
      datalist.append(subjects[1])
      datalist.append(subjects[0])
      datalist.append(subjects[6])

      

      
    if sem==6 and sec=="B":
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append(subjects[6])
      
      
      datalist.append(subjects[2])
      datalist.append(subjects[4])
      datalist.append(subjects[3])
      datalist.append(subjects[5])
      datalist.append(subjects[7])


      datalist.append(subjects[1])
      datalist.append(subjects[3])
      datalist.append(subjects[4])
      datalist.append(subjects[2])
      datalist.append(subjects[5])
      datalist.append(subjects[0])
      datalist.append('leisure')

      
      datalist.append(subjects[4])
      datalist.append(subjects[5])
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[7])
      
      datalist.append(subjects[5])
      datalist.append(subjects[2])
      datalist.append(subjects[1])
      datalist.append(subjects[0])
      datalist.append(subjects[6])

      
      
    if sem==6 and sec=="C":

      
      datalist.append(subjects[4])
      datalist.append(subjects[5])
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[7])
      
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append(subjects[6])

      datalist.append(subjects[1])
      datalist.append(subjects[3])
      datalist.append(subjects[4])
      datalist.append(subjects[2])
      datalist.append(subjects[5])
      datalist.append(subjects[0])
      datalist.append('leisure')

      datalist.append(subjects[5])
      datalist.append(subjects[2])
      datalist.append(subjects[1])
      datalist.append(subjects[0])
      datalist.append(subjects[6])
      
      datalist.append(subjects[2])
      datalist.append(subjects[4])
      datalist.append(subjects[3])
      datalist.append(subjects[5])
      datalist.append(subjects[7])

      

    if sem==7 and sec=="A":
      
      datalist.append(subjects[0])
      datalist.append(subjects[5])
      datalist.append(subjects[5])
      datalist.append(subjects[5])
      datalist.append(subjects[6])
      
      
      datalist.append(subjects[1])
      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append(subjects[4])
      datalist.append('leisure')
      
      
      datalist.append(subjects[2])
      datalist.append(subjects[5])
      datalist.append(subjects[5])
      datalist.append(subjects[5])
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append('leisure')
    

      datalist.append(subjects[3])
      datalist.append(subjects[4])
      datalist.append(subjects[1])
      datalist.append(subjects[0])
      datalist.append('leisure')
      
    
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append(subjects[4])

    

    if sem==7 and sec=="B":
      
      
      datalist.append(subjects[1])
      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append(subjects[4])
      datalist.append('leisure')
      
      datalist.append(subjects[0])
      datalist.append(subjects[5])
      datalist.append(subjects[5])
      datalist.append(subjects[5])
      datalist.append(subjects[6])
      
      
      datalist.append(subjects[2])
      datalist.append(subjects[5])
      datalist.append(subjects[5])
      datalist.append(subjects[5])
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append('leisure')
    
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append(subjects[4])
    

      datalist.append(subjects[3])
      datalist.append(subjects[4])
      datalist.append(subjects[1])
      datalist.append(subjects[0])
      datalist.append('leisure')
      


    if sem==7 and sec=="C":
      
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append(subjects[4])
      
      datalist.append(subjects[0])
      datalist.append(subjects[5])
      datalist.append(subjects[5])
      datalist.append(subjects[5])
      datalist.append(subjects[6])
           
      
      
      datalist.append(subjects[2])
      datalist.append(subjects[5])
      datalist.append(subjects[5])
      datalist.append(subjects[5])
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append('leisure')
    

      datalist.append(subjects[3])
      datalist.append(subjects[4])
      datalist.append(subjects[1])
      datalist.append(subjects[0])
      datalist.append('leisure')
      
      datalist.append(subjects[1])
      datalist.append(subjects[2])
      datalist.append(subjects[3])
      datalist.append(subjects[4])
      datalist.append('leisure')
    


    if sem==8  and sec=="A":
      
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[2])
      datalist.append(subjects[2])
      datalist.append(subjects[2])
      datalist.append(subjects[2])

      datalist.append(subjects[1])
      datalist.append(subjects[0])
      datalist.append(subjects[2])
      datalist.append(subjects[2])
      datalist.append(subjects[2])
      datalist.append(subjects[2])

      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[2])
      datalist.append(subjects[2])
      datalist.append('leisure')

      datalist.append(subjects[1])
      datalist.append(subjects[0])
      datalist.append(subjects[3])
      datalist.append(subjects[3])
      datalist.append(subjects[3])

      datalist.append(subjects[3])
      datalist.append(subjects[3])
      datalist.append(subjects[4])
      datalist.append(subjects[4])
      datalist.append(subjects[4])
      

      datalist.append(subjects[4])
      datalist.append(subjects[4])
      

      


    if sem==8  and sec=="B":
      

      datalist.append(subjects[1])
      datalist.append(subjects[0])
      datalist.append(subjects[2])
      datalist.append(subjects[2])
      datalist.append(subjects[2])
      datalist.append(subjects[2])
      
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[2])
      datalist.append(subjects[2])
      datalist.append(subjects[2])
      datalist.append(subjects[2])

      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[2])
      datalist.append(subjects[2])
      datalist.append('leisure')


      datalist.append(subjects[3])
      datalist.append(subjects[3])
      datalist.append(subjects[4])
      datalist.append(subjects[4])
      datalist.append(subjects[4])
      
      datalist.append(subjects[1])
      datalist.append(subjects[0])
      datalist.append(subjects[3])
      datalist.append(subjects[3])
      datalist.append(subjects[3])

      

      datalist.append(subjects[4])
      datalist.append(subjects[4])
      


    if sem==8  and sec=="A":

      
      datalist.append(subjects[1])
      datalist.append(subjects[0])
      datalist.append(subjects[3])
      datalist.append(subjects[3])
      datalist.append(subjects[3])
      
      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[2])
      datalist.append(subjects[2])
      datalist.append(subjects[2])
      datalist.append(subjects[2])

      datalist.append(subjects[0])
      datalist.append(subjects[1])
      datalist.append(subjects[2])
      datalist.append(subjects[2])
      datalist.append('leisure')
      
      datalist.append(subjects[1])
      datalist.append(subjects[0])
      datalist.append(subjects[2])
      datalist.append(subjects[2])
      datalist.append(subjects[2])
      datalist.append(subjects[2])



      datalist.append(subjects[3])
      datalist.append(subjects[3])
      datalist.append(subjects[4])
      datalist.append(subjects[4])
      datalist.append(subjects[4])
      

      datalist.append(subjects[4])
      datalist.append(subjects[4])
    '''
      
    return datalist
'''  
  def select_and_crossover(subjects,sem):
    print(subjects)
    datalist=[]
    print(len(subjects))
    num=random.randrange(1,20)
    if len(subjects)==8:       
      if num%2==0:
        if num<10:
          datalist.append(subjects[0])
          datalist.append(subjects[1])
          datalist.append(subjects[2])
          datalist.append(subjects[3])
          datalist.append(subjects[6])

          
          datalist.append(subjects[2])
          datalist.append(subjects[3])
          datalist.append(subjects[0])
          datalist.append(subjects[1])
          datalist.append(subjects[7])

          
          datalist.append(subjects[4])
          datalist.append(subjects[0])
          datalist.append(subjects[2])
          datalist.append(subjects[3])
          datalist.append(subjects[5])

          
          datalist.append(subjects[3])
          datalist.append(subjects[2])
          datalist.append(subjects[4])
          datalist.append(subjects[1])
          datalist.append(subjects[6])

          
          datalist.append(subjects[4])
          datalist.append(subjects[2])
          datalist.append(subjects[3])
          datalist.append(subjects[0])
          datalist.append(subjects[5])

          
          datalist.append(subjects[3])
          datalist.append(subjects[2])
          datalist.append(subjects[1])
          datalist.append(subjects[0])
        else:

          
          datalist.append(subjects[2])
          datalist.append(subjects[3])
          datalist.append(subjects[0])
          datalist.append(subjects[1])
          datalist.append(subjects[7])
          
          datalist.append(subjects[0])
          datalist.append(subjects[2])
          datalist.append(subjects[3])
          datalist.append(subjects[1])
          datalist.append(subjects[6])
          

          
          datalist.append(subjects[1])
          datalist.append(subjects[3])
          datalist.append(subjects[4])
          datalist.append(subjects[2])
          datalist.append(subjects[6])

          
          datalist.append(subjects[4])
          datalist.append(subjects[2])
          datalist.append(subjects[3])
          datalist.append(subjects[0])
          datalist.append(subjects[5])

          
          datalist.append(subjects[3])
          datalist.append(subjects[2])
          datalist.append(subjects[0])
          datalist.append(subjects[4])
          datalist.append(subjects[5])

          
          datalist.append(subjects[2])
          datalist.append(subjects[0])
          datalist.append(subjects[1])
          datalist.append(subjects[3])

      else:
        if num<10:
          datalist.append(subjects[2])
          datalist.append(subjects[3])
          datalist.append(subjects[0])
          datalist.append(subjects[1])
          datalist.append(subjects[6])

          
          datalist.append(subjects[2])
          datalist.append(subjects[3])
          datalist.append(subjects[0])
          datalist.append(subjects[1])
          datalist.append(subjects[7])

          
          datalist.append(subjects[3])
          datalist.append(subjects[4])
          datalist.append(subjects[0])
          datalist.append(subjects[2])
          datalist.append(subjects[6])

          
          datalist.append(subjects[3])
          datalist.append(subjects[2])
          datalist.append(subjects[4])
          datalist.append(subjects[1])
          datalist.append(subjects[5])

          
          datalist.append(subjects[2])
          datalist.append(subjects[4])
          datalist.append(subjects[0])
          datalist.append(subjects[3])
          datalist.append(subjects[5])

          
          datalist.append(subjects[3])
          datalist.append(subjects[0])
          datalist.append(subjects[1])
          datalist.append(subjects[2])
        else:

          
          datalist.append(subjects[3])
          datalist.append(subjects[2])
          datalist.append(subjects[0])
          datalist.append(subjects[1])
          datalist.append(subjects[7])
          
          datalist.append(subjects[0])
          datalist.append(subjects[2])
          datalist.append(subjects[3])
          datalist.append(subjects[1])
          datalist.append(subjects[6])
          

          
          datalist.append(subjects[1])
          datalist.append(subjects[3])
          datalist.append(subjects[0])
          datalist.append(subjects[2])
          datalist.append(subjects[6])

          
          
          datalist.append(subjects[3])
          datalist.append(subjects[1])
          datalist.append(subjects[4])
          datalist.append(subjects[2])
          datalist.append(subjects[5])

          
          datalist.append(subjects[3])
          datalist.append(subjects[2])
          datalist.append(subjects[0])
          datalist.append(subjects[4])
          datalist.append(subjects[5])

          
          datalist.append(subjects[2])
          datalist.append(subjects[4])
          datalist.append(subjects[0])
          datalist.append(subjects[3])
    
    else:    
      if num<10:
        datalist.append(subjects[0])
        datalist.append(subjects[1])
        datalist.append(subjects[2])
        datalist.append(subjects[4])
        datalist.append(subjects[5])

        
        datalist.append(subjects[2])
        datalist.append(subjects[4])
        datalist.append(subjects[0])
        datalist.append(subjects[1])
        datalist.append(subjects[3])

        
        datalist.append(subjects[4])
        datalist.append(subjects[0])
        datalist.append(subjects[2])
        datalist.append(subjects[1])
        datalist.append(subjects[5])

        
        datalist.append("--No Class--")
        datalist.append("--No Class--")
        datalist.append("--No Class--")
        datalist.append("--No Class--")
        datalist.append("--No Class--")

        
        datalist.append("--No Class--")
        datalist.append("--No Class--")
        datalist.append("--No Class--")
        datalist.append("--No Class--")
        datalist.append("--No Class--")

        
        datalist.append("--No Class--")
        datalist.append("--No Class--")
        datalist.append("--No Class--")
        datalist.append("--No Class--")
        datalist.append("--No Class--")
      else:

        

        
        datalist.append("--No Class--")
        datalist.append("--No Class--")
        datalist.append("--No Class--")
        datalist.append("--No Class--")
        datalist.append("--No Class--")

        
        datalist.append(subjects[2])
        datalist.append(subjects[4])
        datalist.append(subjects[0])
        datalist.append(subjects[1])
        datalist.append(subjects[3])

        
        datalist.append("--No Class--")
        datalist.append("--No Class--")
        datalist.append("--No Class--")
        datalist.append("--No Class--")
        datalist.append("--No Class--")

        
        datalist.append(subjects[0])
        datalist.append(subjects[1])
        datalist.append(subjects[2])
        datalist.append(subjects[4])
        datalist.append(subjects[5])

        
        datalist.append("--No Class--")
        datalist.append("--No Class--")
        datalist.append("--No Class--")
        datalist.append("--No Class--")
        datalist.append("--No Class--")
        
        datalist.append(subjects[4])
        datalist.append(subjects[0])
        datalist.append(subjects[2])
        datalist.append(subjects[1])
        datalist.append(subjects[5])

      
    return datalist
'''
